###
### This homework is modified from CS231.
###


import sys
import numpy as np
import os
from scipy.optimize import least_squares
import math
from copy import deepcopy
from skimage.io import imread
from sfm_utils import *

'''
ESTIMATE_INITIAL_RT from the Essential Matrix, we can compute 4 initial
guesses of the relative RT between the two cameras
Arguments:
    E - the Essential Matrix between the two cameras
Returns:
    RT: A 4x3x4 tensor in which the 3x4 matrix RT[i,:,:] is one of the
        four possible transformations
'''
def estimate_initial_RT(E):
    U,S,V_t = np.linalg.svd(E)
    Z = np.array([[0, 1, 0],[ -1, 0, 0],[ 0 ,0 ,0]]);
    W = np.array([[0, -1, 0],[ 1, 0, 0],[ 0 ,0 ,1]]);
    # E = MQ
    # essential matrix include the R and T
    # after SVD, the right vector is the rotation matrix orthogonal matrix
    # the left vector is translation orthogonal matrix
    # T_x*R = E
    Q1 = U @ W @ V_t;
    Q2 = U @ W.T @ V_t;
    R1 = np.linalg.det(Q1)*Q1;
    R2 = np.linalg.det(Q2)*Q2;
    # print(Q1)
    T1 = np.array(U[:, 2]).reshape(3,1)
    T2 = np.array(-U[:, 2]).reshape(3,1)
    # print(T1)
    # print(np.hstack([R1,T1]))
    RT = np.array([np.hstack([R1,T1]), np.hstack([R1,T2]), np.hstack([R2,T1]),np.hstack([R1,T2])])
    
    # print(RT)


    return RT;
    #raise Exception('Not Implemented Error')

'''
LINEAR_ESTIMATE_3D_POINT given a corresponding points in different images,
compute the 3D point is the best linear estimate
Arguments:
    image_points - the measured points in each of the M images (Mx2 matrix)
    camera_matrices - the camera projective matrices (Mx3x4 tensor)
Returns:
    point_3d - the 3D point
'''
def linear_estimate_3d_point(image_points, camera_matrices):
    
    ## notice the image_points will be 2 and 4 in shape[0];
    ## not 2*2 matrix for all
    
    # test
    # print(camera_matrices[:, 2, :])
    # print(image_points[:,1].shape)
    # print(image_points[:, 1] * camera_matrices[:, 2, :].T)
    # image_matrix 2 3 4
    # print(camera_matrices)
    # print(camera_matrices[:, 2, :])
    # if(image_points.shape[0] == 2):
    # F1 = image_points[0, 1] * camera_matrices[0, 2, :] - camera_matrices[0, 1, :];
    # F2 = image_points[1, 1] * camera_matrices[1, 2, :] - camera_matrices[1, 1, :];
    # F3 = camera_matrices[0, 0, :] - image_points[0,0] * camera_matrices[0, 2, :];
    # F4 = camera_matrices[1, 0, :] - image_points[1,0] * camera_matrices[1, 2, :];
    # F = np.vstack([F1, F2, F3, F4]);
    # U, S, V_t = np.linalg.svd(F);
    # point_3D = V_t[3, :];
    # point_3D /= point_3D[3];
    # #raise Exception('Not Implemented Error')
    # point_3D = point_3D[0:3];
    # return point_3D
    
    ## general form
    catch = [];
    for i in range(image_points.shape[0]):
        temp = image_points[i, 1] * camera_matrices[i, 2, :] - camera_matrices[i, 1, :];
        catch.append(temp);
    F1 = np.array(catch)
    
    catch = [];
    for i in range(image_points.shape[0]):
        temp =  camera_matrices[i, 0, :] - image_points[i, 0] * camera_matrices[i, 2, :];
        catch.append(temp);
    F2 = np.array(catch)
    
    F_M = np.vstack([F1, F2])

    U, sigma, V_transpose = np.linalg.svd(F_M)
    point_3d = V_transpose[3, :].copy()
    point_3d /= point_3d[-1]
    return point_3d[:-1]
        
'''
REPROJECTION_ERROR given a 3D point and its corresponding points in the image
planes, compute the reprojection error vector and associated Jacobian
Arguments:
    point_3d - the 3D point corresponding to points in the image
    image_points - the measured points in each of the M images (Mx2 matrix)
    camera_matrices - the camera projective matrices (Mx3x4 tensor)
Returns:
    error - the 2M reprojection error vector
'''
def reprojection_error(point_3d, image_points, camera_matrices):
    ## notice the image_points will be 2 and 4 in shape[0];
    ## not 2*2 matrix for all
    ## Change to general form
    
    # # y = Mi * P
    # # print(camera_matrices)
    # # print(image_points)
    # point_3d = np.append(point_3d, 1);
    # # print(point_3d)
    # y1 = camera_matrices[0,:,:] @ point_3d;
    # y2 = camera_matrices[1,:,:] @ point_3d;
    # y1 /= y1[2];
    # y2 /= y2[2];
    # y1 = y1[0:2];
    # y2 = y2[0:2];
    # # y = np.matmul(camera_matrices, point_3d)
    # # print(image_points)
    # # print(y)
    
    # e1 = y1 - image_points[0,:];
    # e2 = y2 - image_points[1,:];
    # # e3 = y3 - 
    # # output 1 * 4 matrix
    # e = np.append(e1,e2)
    # # print(e)
    # # print(e1)
    
    ## general form
    point_3d = np.append(point_3d,1);
    
    y = (camera_matrices @ point_3d); # 2*3 matrix => 3*2 matrix
    # print(y)
    for i in range(y.shape[0]):
        y[i,:] /= y[i,-1];
    y = y[:,0:-1];
    e = y - image_points;
    # print(e)
    e = e.reshape(1,e.shape[1]*e.shape[0]);
    # print(e)
    return e;
'''
JACOBIAN given a 3D point and its corresponding points in the image
planes, compute the reprojection error vector and associated Jacobian
Arguments:
    point_3d - the 3D point corresponding to points in the image
    camera_matrices - the camera projective matrices (Mx3x4 tensor)
Returns:
    jacobian - the 2Mx3 Jacobian matrix
'''
def jacobian(point_3d, camera_matrices):
    
    ## we need general form, because the camera_matrices is not the same for all process.
    
    point_3d = np.append(point_3d,1);
    den = (camera_matrices[:, 2, :] @ point_3d) ** 2 # depend on your camera matric M
    # print(camera_matrices)
    # den1 = (camera_matrices[0, 2, :] @ point_3d) ** 2
    # den2 = (camera_matrices[1, 2, :] @ point_3d) ** 2
    # de1_dx1 = camera_matrices[0, 0, 0] * camera_matrices[0, 2, :] @ point_3d - camera_matrices[0, 2, 0] * camera_matrices[0, 0, :] @ point_3d;
    # de1_dy1 = camera_matrices[0, 0, 1] * camera_matrices[0, 2, :] @ point_3d - camera_matrices[0, 2, 1] * camera_matrices[0, 0, :] @ point_3d;
    # de1_dz1 = camera_matrices[0, 0, 2] * camera_matrices[0, 2, :] @ point_3d - camera_matrices[0, 2, 2] * camera_matrices[0, 0, :] @ point_3d;
    # de1_dx2 = camera_matrices[0, 1, 0] * camera_matrices[0, 2, :] @ point_3d - camera_matrices[0, 2, 0] * camera_matrices[0, 1, :] @ point_3d;
    # de1_dy2 = camera_matrices[0, 1, 1] * camera_matrices[0, 2, :] @ point_3d - camera_matrices[0, 2, 1] * camera_matrices[0, 1, :] @ point_3d;
    # de1_dz2 = camera_matrices[0, 1, 2] * camera_matrices[0, 2, :] @ point_3d - camera_matrices[0, 2, 2] * camera_matrices[0, 1, :] @ point_3d;
    
    # de2_dx1 = camera_matrices[1, 0, 0] * camera_matrices[1, 2, :] @ point_3d - camera_matrices[1, 2, 0] * camera_matrices[1, 0, :] @ point_3d;
    # de2_dy1 = camera_matrices[1, 0, 1] * camera_matrices[1, 2, :] @ point_3d - camera_matrices[1, 2, 1] * camera_matrices[1, 0, :] @ point_3d;
    # de2_dz1 = camera_matrices[1, 0, 2] * camera_matrices[1, 2, :] @ point_3d - camera_matrices[1, 2, 2] * camera_matrices[1, 0, :] @ point_3d;
    # de2_dx2 = camera_matrices[1, 1, 0] * camera_matrices[1, 2, :] @ point_3d - camera_matrices[1, 2, 0] * camera_matrices[1, 1, :] @ point_3d;
    # de2_dy2 = camera_matrices[1, 1, 1] * camera_matrices[1, 2, :] @ point_3d - camera_matrices[1, 2, 1] * camera_matrices[1, 1, :] @ point_3d;
    # de2_dz2 = camera_matrices[1, 1, 2] * camera_matrices[1, 2, :] @ point_3d - camera_matrices[1, 2, 2] * camera_matrices[1, 1, :] @ point_3d; 

    de_dx1 = camera_matrices[:, 0, 0]*(camera_matrices[:, 2, :] @ point_3d) - camera_matrices[:, 2, 0]*(camera_matrices[:, 0, :] @ point_3d);
    de_dy1 = camera_matrices[:, 0, 1]*(camera_matrices[:, 2, :] @ point_3d) - camera_matrices[:, 2, 1]*(camera_matrices[:, 0, :] @ point_3d);
    de_dz1 = camera_matrices[:, 0, 2]*(camera_matrices[:, 2, :] @ point_3d) - camera_matrices[:, 2, 2]*(camera_matrices[:, 0, :] @ point_3d);
    de_dx2 = camera_matrices[:, 1, 0]*(camera_matrices[:, 2, :] @ point_3d) - camera_matrices[:, 2, 0]*(camera_matrices[:, 1, :] @ point_3d);
    de_dy2 = camera_matrices[:, 1, 1]*(camera_matrices[:, 2, :] @ point_3d) - camera_matrices[:, 2, 1]*(camera_matrices[:, 1, :] @ point_3d);
    de_dz2 = camera_matrices[:, 1, 2]*(camera_matrices[:, 2, :] @ point_3d) - camera_matrices[:, 2, 2]*(camera_matrices[:, 1, :] @ point_3d);
    for i in range(den.shape[0]):
        de_dx1[i] /= den[i];
        de_dy1[i] /= den[i];
        de_dz1[i] /= den[i];
        de_dx2[i] /= den[i];
        de_dy2[i] /= den[i];
        de_dz2[i] /= den[i];
    jacx = np.vstack([[de_dx1],[de_dx2]]);
    jacy = np.vstack([[de_dy1],[de_dy2]]);
    jacz = np.vstack([[de_dz1],[de_dz2]]);
    jac_t = [];
    for i in range(jacx.shape[1]):
        jac_tot = np.vstack([jacx[:,i],jacy[:,i],jacz[:,i]]).T
        # print(jac_tot)
        jac_t.append(jac_tot);

    jac_t = np.array(jac_t).reshape(2*den.shape[0],3)
    return jac_t


'''
NONLINEAR_ESTIMATE_3D_POINT given a corresponding points in different images,
compute the 3D point that iteratively updates the points
Arguments:
    image_points - the measured points in each of the M images (Mx2 matrix)
    camera_matrices - the camera projective matrices (Mx3x4 tensor)
Returns:
    point_3d - the 3D point
'''
def nonlinear_estimate_3d_point(image_points, camera_matrices):
    # use linear_estimated_3d_point
    P_3d = linear_estimate_3d_point(image_points, camera_matrices);
    P_3d = np.array(P_3d).reshape(3,1)
    # print(P_3d)
    # print(camera_matrices)
    for i in range(0,10):
        J = jacobian(P_3d,camera_matrices);
        e = reprojection_error(P_3d, image_points, camera_matrices);
        P_3d = P_3d - np.linalg.inv(J.T @ J) @ J.T @ np.array(e).reshape(e.shape[1],1);
    P_3d = P_3d.reshape(1,3)
        
    return P_3d;

'''
ESTIMATE_RT_FROM_E from the Essential Matrix, we can compute  the relative RT 
between the two cameras
Arguments:
    E - the Essential Matrix between the two cameras
    image_points - N measured points in each of the M images (NxMx2 matrix)
    K - the intrinsic camera matrix
Returns:
    RT: The 3x4 matrix which gives the rotation and translation between the 
        two cameras
'''
def estimate_RT_from_E(E, image_points, K):
    # 4 RT matrix
    estimated_4_RT = estimate_initial_RT(E);
    # The first camera K*[R T]
    M1 = K @ np.hstack([np.eye(3),np.zeros([3,1])]);
    # The second camera K*[R T]
    count = [0, 0, 0, 0]
    for im_p in range(image_points.shape[0]):
        for rt_index in range(4):
            M2 = K @ estimated_4_RT[rt_index,:,:];
            # like the dimension from the part B         
            M_t =np.array([M1,M2]);
            point_3d = linear_estimate_3d_point(image_points[im_p], M_t);
            point_3d_2 = estimated_4_RT[rt_index,:,:]@ np.append(point_3d,1).reshape(4,1);
            if(point_3d[2] > 0 and point_3d_2[2] > 0):
                count[rt_index]+=1; 
    ind = np.argmax(count)   
    return estimated_4_RT[ind];


if __name__ == '__main__':
    run_pipeline = True

    # Load the data
    image_data_dir = 'data/statue/'
    unit_test_camera_matrix = np.load('data/unit_test_camera_matrix.npy')
    unit_test_image_matches = np.load('data/unit_test_image_matches.npy')
    image_paths = [os.path.join(image_data_dir, 'images', x) for x in
        sorted(os.listdir('data/statue/images')) if '.jpg' in x]
    focal_length = 719.5459
    matches_subset = np.load(os.path.join(image_data_dir,
        'matches_subset.npy'), allow_pickle=True, encoding='latin1')[0,:]
    dense_matches = np.load(os.path.join(image_data_dir, 'dense_matches.npy'), 
                               allow_pickle=True, encoding='latin1')
    fundamental_matrices = np.load(os.path.join(image_data_dir,
        'fundamental_matrices.npy'), allow_pickle=True, encoding='latin1')[0,:]

    # Part A: Computing the 4 initial R,T transformations from Essential Matrix
    print('-' * 80)
    print("Part A: Check your matrices against the example R,T")
    print('-' * 80)
    K = np.eye(3)
    K[0,0] = K[1,1] = focal_length
    E = K.T.dot(fundamental_matrices[0]).dot(K)
    im0 = imread(image_paths[0])
    im_height, im_width, _ = im0.shape
    example_RT = np.array([[0.9736, -0.0988, -0.2056, 0.9994],
        [0.1019, 0.9948, 0.0045, -0.0089],
        [0.2041, -0.0254, 0.9786, 0.0331]])
    print("Example RT:\n", example_RT)
    estimated_RT = estimate_initial_RT(E)
    print('')
    print("Estimated RT:\n", estimated_RT)

    # Part B: Determining the best linear estimate of a 3D point
    print('-' * 80)
    print('Part B: Check that the difference from expected point ')
    print('is near zero')
    print('-' * 80)
    camera_matrices = np.zeros((2, 3, 4))
    camera_matrices[0, :, :] = K.dot(np.hstack((np.eye(3), np.zeros((3,1)))))
    camera_matrices[1, :, :] = K.dot(example_RT)
    unit_test_matches = matches_subset[0][:,0].reshape(2,2)
    estimated_3d_point = linear_estimate_3d_point(unit_test_matches.copy(),
        camera_matrices.copy())
    expected_3d_point = np.array([0.6774, -1.1029, 4.6621])
    # print(unit_test_matches)
    # test
    # print(estimated_3d_point)
    # print(expected_3d_point)
    # forget to delete the last dimension !!
    
    print("Difference: ", np.fabs(estimated_3d_point - expected_3d_point).sum())

    # Part C: Calculating the reprojection error and its Jacobian
    print('-' * 80)
    print('Part C: Check that the difference from expected error/Jacobian ')
    print('is near zero')
    print('-' * 80)
    estimated_error = reprojection_error(
            expected_3d_point, unit_test_matches, camera_matrices)
    estimated_jacobian = jacobian(expected_3d_point, camera_matrices)
    expected_error = np.array((-0.0095458, -0.5171407,  0.0059307,  0.501631))
    print("Error Difference: ", np.fabs(estimated_error - expected_error).sum())
    expected_jacobian = np.array([[ 154.33943931, 0., -22.42541691],
          [0., 154.33943931, 36.51165089],
          [141.87950588, -14.27738422, -56.20341644],
          [21.9792766, 149.50628901, 32.23425643]])
    print("Jacobian Difference: ", np.fabs(estimated_jacobian
        - expected_jacobian).sum())

    # Part D: Determining the best nonlinear estimate of a 3D point
    print('-' * 80)
    print('Part D: Check that the reprojection error from nonlinear method')
    print('is lower than linear method')
    print('-' * 80)
    estimated_3d_point_linear = linear_estimate_3d_point(
        unit_test_image_matches.copy(), unit_test_camera_matrix.copy())
    # print(unit_test_image_matches)
    estimated_3d_point_nonlinear = nonlinear_estimate_3d_point(
        unit_test_image_matches.copy(), unit_test_camera_matrix.copy())
    error_linear = reprojection_error(
        estimated_3d_point_linear, unit_test_image_matches,
        unit_test_camera_matrix)
    print("Linear method error:", np.linalg.norm(error_linear))
    error_nonlinear = reprojection_error(
        estimated_3d_point_nonlinear, unit_test_image_matches,
        unit_test_camera_matrix)
    print("Nonlinear method error:", np.linalg.norm(error_nonlinear))
    
    # positive means the Linear error is larger than Nonlinear one.
    # print("Difference between Nonlinear method error and Linear method error: ",  np.linalg.norm(error_linear) - np.linalg.norm(error_nonlinear))
    
    
    # Part E: Determining the correct R, T from Essential Matrix
    print('-' * 80)
    print("Part E: Check your matrix against the example R,T")
    print('-' * 80)
    estimated_RT = estimate_RT_from_E(E,
        np.expand_dims(unit_test_image_matches[:2,:], axis=0), K)
    print("Example RT:\n", example_RT)
    print('')
    print("Estimated RT:\n", estimated_RT)

    # Part F: Run the entire Structure from Motion pipeline
    if not run_pipeline:
        sys.exit()
    print('-' * 80)
    print('Part F: Run the entire SFM pipeline')
    print('-' * 80)
    frames = [0] * (len(image_paths) - 1)
    for i in range(len(image_paths)-1):
        frames[i] = Frame(matches_subset[i].T, focal_length,
                fundamental_matrices[i], im_width, im_height)
        bundle_adjustment(frames[i])
    merged_frame = merge_all_frames(frames)

    # Construct the dense matching
    camera_matrices = np.zeros((2,3,4))
    dense_structure = np.zeros((0,3))
    for i in range(len(frames)-1):
        matches = dense_matches[i]
        camera_matrices[0,:,:] = merged_frame.K.dot(
            merged_frame.motion[i,:,:])
        camera_matrices[1,:,:] = merged_frame.K.dot(
                merged_frame.motion[i+1,:,:])
        points_3d = np.zeros((matches.shape[1], 3))
        use_point = np.array([True]*matches.shape[1])
        for j in range(matches.shape[1]):
            points_3d[j,:] = nonlinear_estimate_3d_point(
                matches[:,j].reshape((2,2)), camera_matrices)
        dense_structure = np.vstack((dense_structure, points_3d[use_point,:]))

    np.save('results.npy', dense_structure)
    print ('Save results to results.npy!')
